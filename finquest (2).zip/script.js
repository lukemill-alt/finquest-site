document.getElementById('preorder-form').addEventListener('submit', function(e){
  e.preventDefault();
  alert("Thank you! Your preorder has been received (demo).");
});
