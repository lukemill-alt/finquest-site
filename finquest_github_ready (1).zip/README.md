# FinQuest — Smart Finance for Students

A gamified finance tool designed to help students learn, manage, and improve their financial literacy.

## 🚀 Deploy for Free Using GitHub Pages

1. Create a GitHub repository named `finquest-site`.
2. Upload `index.html` and `README.md`.
3. In Settings → Pages → set the source to `main` branch.
4. Your live site will appear at `https://<your-username>.github.io/finquest-site/`.
